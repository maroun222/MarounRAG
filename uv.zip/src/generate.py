#After the program asks for a question and the user enter the question, the same BGE model, 
# is used to covert the question into a vector [Use same embedding for PDF chunks and User questions]
#  llama3.2:1b-instruct-q4_K_M is a model that receives the user's question, selected passage, page number, intructions to answers
#   it doesn't search the PDF, it only refolmulates the passage into a short answer

### Not every answer will be correct because:

# The PDF extraction may contain noise.
# Chunking is not perfect.
# Semantic retrieval can confuse similar sections.
# The embedding and reranking models are lightweight.
# Llama 3.2 1B is a small local model.


import re
import weaviate

from langchain_huggingface import HuggingFaceEmbeddings
from ollama import chat
from sentence_transformers import CrossEncoder
from weaviate.classes.query import MetadataQuery

import os

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

# Load the embedding model once
embedding_model = HuggingFaceEmbeddings(
    model_name="BAAI/bge-small-en-v1.5",
    model_kwargs={"device": "cpu"},
    encode_kwargs={"normalize_embeddings": True},
)


# Load the reranking model once
reranker = CrossEncoder(
    "cross-encoder/ms-marco-MiniLM-L4-v2",
    device="cpu",
)


# Connect to Weaviate once
client = weaviate.connect_to_local()
collection = client.collections.use("CISControls")


try:
    while True:
        question = input(
            "\nEnter your question, or type 'exit': "
        ).strip()

        if question.lower() in {"exit", "quit"}:
            break

        if not question:
            continue


        # 1. Convert the question into a vector
        query_vector = embedding_model.embed_query(question)


        # 2. Retrieve 10 candidate chunks
        results = collection.query.near_vector(
            near_vector=query_vector,
            target_vector="default",
            limit=10,
            return_properties=["text", "page_number"],
            return_metadata=MetadataQuery(distance=True),
        )

        print("Retrieved candidates:", len(results.objects))

        if not results.objects:
            print("No relevant passages were found.")
            continue


        # 3. Rerank the retrieved chunks
        pairs = []

        for result in results.objects:
            text = result.properties.get("text", "")
            pairs.append([question, text])

        scores = reranker.predict(pairs)

        ranked_results = list(zip(results.objects, scores))

        ranked_results.sort(
            key=lambda item: float(item[1]),
            reverse=True,
        )


        # 4. Join headings with their descriptions
        passages_by_text = {}

        for result, chunk_score in ranked_results[:5]:
            page = int(result.properties.get("page_number", 0))
            text = result.properties.get("text", "")

            blocks = [
                " ".join(block.split())
                for block in text.split("\n\n")
                if block.strip()
            ]

            current_heading = None

            for block in blocks:
                words = re.findall(r"[A-Za-z]+", block)

                # Save meaningful headings
                if len(block) < 150 and len(words) >= 3:
                    current_heading = block
                    continue

                # Ignore short OCR noise
                if len(block) < 60:
                    continue

                if current_heading:
                    passage = current_heading + "\n" + block
                else:
                    passage = block

                key = passage.lower()

                # Remove duplicate passages
                if (
                    key not in passages_by_text
                    or page < passages_by_text[key]["page"]
                ):
                    passages_by_text[key] = {
                        "text": passage,
                        "page": page,
                    }

                current_heading = None


        passages = list(passages_by_text.values())

        if not passages:
            print("No useful passages were found.")
            continue


        # 5. Rerank the smaller heading-description passages
        passage_pairs = []

        for passage in passages:
            passage_pairs.append(
                [
                    question,
                    passage["text"],
                ]
            )

        passage_scores = reranker.predict(passage_pairs)


        # Words that are not useful for distinguishing passages
        stop_words = {
            "how", "should", "the", "a", "an", "for", "to",
            "of", "is", "are", "be", "with", "and", "often",
            "frequently",
        }

        question_words = {
            word.lower()
            for word in re.findall(r"[A-Za-z]+", question)
            if word.lower() not in stop_words
        }

        combined_scores = []

        for index, passage in enumerate(passages):
            heading = passage["text"].split("\n", 1)[0]

            heading_words = {
                word.lower()
                for word in re.findall(r"[A-Za-z]+", heading)
            }

            semantic_score = float(passage_scores[index])

            heading_matches = len(
                question_words & heading_words
            )

            combined_score = (
                semantic_score
                + 1.5 * heading_matches
            )

            # Prevent confusion between active and passive discovery
            if (
                "active" in question_words
                and "passive" in heading_words
            ):
                combined_score -= 5

            if (
                "passive" in question_words
                and "active" in heading_words
            ):
                combined_score -= 5

            combined_scores.append(combined_score)


        best_index = max(
            range(len(passages)),
            key=lambda index: combined_scores[index],
        )

        best_passage = passages[best_index]
        best_text = best_passage["text"]
        best_page = best_passage["page"]


        print("\nBest passage sent to the model:")
        print("=" * 70)
        print("Page:", best_page)
        print(best_text)


        # 6. Generate the final answer with Ollama
        system_message = """
You are an extractive question-answering assistant.

Answer using only the supplied passage.

Rules:
- Identify the exact actions and frequencies written in the passage.
- Preserve exact frequencies, intervals, and action options.
- Do not add information from other topics.
- Give a short and direct answer.
- Mention the supplied page number.
- If the passage does not answer the question, say that the context is insufficient.
"""


        user_message = f"""
Question:
{question}

Passage from page {best_page}:
{best_text}

Write the answer in one or two sentences.
"""


        response = chat(
            model="llama3.2:1b-instruct-q4_K_M",
            messages=[
                {
                    "role": "system",
                    "content": system_message,
                },
                {
                    "role": "user",
                    "content": user_message,
                },
            ],
            options={
                "temperature": 0.0,
                "num_ctx": 1024,
                "num_predict": 120,
            },
        )


        print("\nGenerated answer:")
        print("=" * 70)
        print(response.message.content)


finally:
    client.close()
    print("\nProgram closed")